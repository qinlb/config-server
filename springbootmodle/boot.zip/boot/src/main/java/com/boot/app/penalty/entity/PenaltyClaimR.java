package com.boot.app.penalty.entity;

   /**
    * @文件名称：penaltyClaimR.java
    * @创建时间：2019-05-06 18:18:35
    * @创  建  人：qinlb 
    * @文件描述：upload_penalty_claim_r 实体类
    */ 


public class PenaltyClaimR{
	private String claimNumber;
	private String timeStamp;
	private String claimId;
	private String descClaimId;
	private String penaltyBatch;
	private String type;
	private Integer isUsed;
	public void setClaimNumber(String claimNumber){
	this.claimNumber=claimNumber;
	}
	public String getClaimNumber(){
		return claimNumber;
	}
	public void setTimeStamp(String timeStamp){
	this.timeStamp=timeStamp;
	}
	public String getTimeStamp(){
		return timeStamp;
	}
	public void setClaimId(String claimId){
	this.claimId=claimId;
	}
	public String getClaimId(){
		return claimId;
	}
	public void setDescClaimId(String descClaimId){
	this.descClaimId=descClaimId;
	}
	public String getDescClaimId(){
		return descClaimId;
	}
	public void setPenaltyBatch(String penaltyBatch){
	this.penaltyBatch=penaltyBatch;
	}
	public String getPenaltyBatch(){
		return penaltyBatch;
	}
	public void setType(String type){
	this.type=type;
	}
	public String getType(){
		return type;
	}
	public void setIsUsed(Integer isUsed){
	this.isUsed=isUsed;
	}
	public Integer getIsUsed(){
		return isUsed;
	}
}

