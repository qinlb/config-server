package com.boot.app.common.aop.util;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
 
/**
 * 从数据库表反射出实体类，自动生成实体类
 * 
 * @author qinlb
 *
 */
public class SqlHelper {
	//基本数据配置
	private String packageOutPath = "com.boot.app.penalty.";// 指定实体生成所在包的路径
	private String authorName = "qinlb";// 作者名字
	private String tablename = "upload_penalty_claim_r";// 表名
	private String entityName = "penaltyClaimR";
	private String[] colnames; // 列名数组
	private String[] propertyNames;
	private String[] colTypes; // 列名类型数组
//	private String version = "V0.01"; // 版本
	private int[] colSizes; // 列名大小数组
	private boolean f_util = false; // 是否需要导入包java.util.*
	private boolean f_sql = false; // 是否需要导入包java.sql.*
	private boolean f_lang = false; // 是否需要导入包java.sql.*
	private String defaultPath = "/src/main/java/";
	private String defaultPath2 = "/src/main/resources/";
	private boolean f_springboot = true;
	// 数据库连接
	private static final String URL = "jdbc:mysql://10.96.111.130:3306/lclaim?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true&zeroDateTimeBehavior=convertToNull";
	private static final String NAME = "p_xiaokun4";
	private static final String PASS = "1qazxsw2";
	private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
 
	/*
	 * 构造函数
	 */
	public SqlHelper() {
		// 创建连接
		Connection con;
		// 查要生成实体类的表
		String sql = "select * from " + tablename;
		PreparedStatement pStemt = null;
		try {
			try {
				Class.forName(DRIVER);
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			con = DriverManager.getConnection(URL, NAME, PASS);
			pStemt = con.prepareStatement(sql);
			ResultSetMetaData rsmd = pStemt.getMetaData();
			int size = rsmd.getColumnCount(); // 统计列
			colnames = new String[size];
			propertyNames = new String[size];
			colTypes = new String[size];
			colSizes = new int[size];
			for (int i = 0; i < size; i++) {
 
				colnames[i] = rsmd.getColumnName(i + 1);
				propertyNames[i] = this.colscap(colnames[i].toLowerCase());
				colTypes[i] = rsmd.getColumnTypeName(i + 1);
				//自动生成包配置
				
				
				// if (colTypes[i].equalsIgnoreCase("datetime")) {
				// f_util = true;
				// }
				if (colTypes[i].equalsIgnoreCase("image") || colTypes[i].equalsIgnoreCase("text")
						|| colTypes[i].equalsIgnoreCase("datetime") || colTypes[i].equalsIgnoreCase("time")
						|| colTypes[i].equalsIgnoreCase("date") || colTypes[i].equalsIgnoreCase("datetime2")) {
					f_sql = true;
				}
				// if (colTypes[i].equalsIgnoreCase("int")) {
				// f_lang = true;
				// }
				colSizes[i] = rsmd.getColumnDisplaySize(i + 1);
			}
			createEntity();
			createDao();
			createMapper();
			createServiceInterface();
			createServiceimpl();
			createController();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
		}
	}
 
	/**
	 * 功能：生成实体类主体代码
	 * 
	 * @param colnames
	 * @param colTypes
	 * @param colSizes
	 * @return
	 */
	private String parseEntity(String[] colnames, String[] colTypes, int[] colSizes) {
		StringBuffer sb = new StringBuffer();
		// 生成package包路径
		sb.append("package " + this.packageOutPath+"entity" + ";\r\n");
		// 判断是否导入工具包
		if (f_util) {
			sb.append("import java.util.Date;\r\n");
		}
		if (f_sql) {
			sb.append("import java.sql.*;\r\n");
		}
		if (f_lang) {
			sb.append("import java.lang.*;\r\n");
		}
 
		sb.append("\r\n");
		// 注释部分
		sb.append("   /**\r\n");
		sb.append("    * @文件名称：" + this.entityName + ".java\r\n");
		sb.append("    * @创建时间：" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + "\r\n");
		sb.append("    * @创  建  人：" + this.authorName + " \r\n");
		sb.append("    * @文件描述：" + tablename + " 实体类\r\n");
//		sb.append("    * @文件版本：" + this.version + " \r\n");
		sb.append("    */ \r\n");
		// 实体部分
		sb.append("\r\n\r\npublic class " + initcap(entityName) + "{\r\n");
		processAllAttrs(sb);// 属性
		processAllMethod(sb);// get set方法
		sb.append("}\r\n");
 
		// System.out.println(sb.toString());
		return sb.toString();
	}
 
	/**
	 * 功能：生成所有属性
	 * 
	 * @param sb
	 */
	private void processAllAttrs(StringBuffer sb) {
 
		for (int i = 0; i < propertyNames.length; i++) {
			sb.append("\tprivate " + sqlType2JavaType(colTypes[i]) + " " + propertyNames[i] + ";\r\n");
		}
 
	}
 
	/**
	 * 功能：生成所有方法
	 * 
	 * @param sb
	 */
	private void processAllMethod(StringBuffer sb) {
 
		for (int i = 0; i < propertyNames.length; i++) {
			sb.append("\tpublic void set" + initcap(propertyNames[i]) + "(" + sqlType2JavaType(colTypes[i]) + " "
					+ propertyNames[i] + "){\r\n");
			sb.append("\tthis." + propertyNames[i] + "=" + propertyNames[i] + ";\r\n");
			sb.append("\t}\r\n");
			sb.append("\tpublic " + sqlType2JavaType(colTypes[i]) + " get" + initcap(propertyNames[i]) + "(){\r\n");
			sb.append("\t\treturn " + propertyNames[i] + ";\r\n");
			sb.append("\t}\r\n");
		}
 
	}
 
	/**
	 * 功能：将输入字符串的首字母改成大写
	 * 
	 * @param str
	 * @return
	 */
	private String initcap(String str) {
 
		char[] ch = str.toCharArray();
		if (ch[0] >= 'a' && ch[0] <= 'z') {
			ch[0] = (char) (ch[0] - 32);
		}
 
		return new String(ch);
	}
 
	private String colscap(String colName){
		String[] partCols = colName.split("_");
		if(partCols.length > 1){
			String newColName = partCols[0];
			for(int i=1; i<partCols.length;i++){
				newColName += initcap(partCols[i]);
			}
			return newColName;
		}
		return colName;
	}
	
	/**
	 * 功能：获得列的数据类型
	 * 
	 * @param sqlType
	 * @return
	 */
	private String sqlType2JavaType(String sqlType) {
 
		if (sqlType.equalsIgnoreCase("bit")) {
			return "Boolean";
		} else if (sqlType.equalsIgnoreCase("decimal") || sqlType.equalsIgnoreCase("money")
				|| sqlType.equalsIgnoreCase("smallmoney") || sqlType.equalsIgnoreCase("numeric")
				|| sqlType.equalsIgnoreCase("bigint")) {
			return "Long";
		} else if (sqlType.equalsIgnoreCase("float")) {
			return "Double";
		} else if (sqlType.equalsIgnoreCase("int") || sqlType.equalsIgnoreCase("int identity")) {
			return "Integer";
		} else if (sqlType.equalsIgnoreCase("image") || sqlType.equalsIgnoreCase("varbinary(max)")
				|| sqlType.equalsIgnoreCase("varbinary") || sqlType.equalsIgnoreCase("udt")
				|| sqlType.equalsIgnoreCase("timestamp") || sqlType.equalsIgnoreCase("binary")) {
			return "Byte[]";
		} else if (sqlType.equalsIgnoreCase("nchar") || sqlType.equalsIgnoreCase("nvarchar(max)")
				|| sqlType.equalsIgnoreCase("nvarchar") || sqlType.equalsIgnoreCase("nvarchar(ntext)")
				|| sqlType.equalsIgnoreCase("uniqueidentifier") || sqlType.equalsIgnoreCase("xml")
				|| sqlType.equalsIgnoreCase("char") || sqlType.equalsIgnoreCase("varchar(max)")
				|| sqlType.equalsIgnoreCase("text") || sqlType.equalsIgnoreCase("varchar")) {
			return "String";
		} else if (sqlType.equalsIgnoreCase("real")) {
			return "Float";
		} else if (sqlType.equalsIgnoreCase("smallint") || sqlType.equalsIgnoreCase("tinyint")) {
			return "Short";
		} else if (sqlType.equalsIgnoreCase("date") || sqlType.equalsIgnoreCase("datetime")
				|| sqlType.equalsIgnoreCase("time") || sqlType.equalsIgnoreCase("datetime2")) {
			return "Date";
		} else {
			System.out.println("数据类型异常，类型为：" + sqlType);
		}
 
		return null;
	}
 
	/**
	 * @实体类 TODO
	 */
	private void createEntity(){
		 
		try {
			String content = parseEntity(colnames, colTypes, colSizes);
			File directory = new File("");
			
			String path = this.getClass().getResource("").getPath();

			System.out.println(path);
			
			String outputPath = directory.getAbsolutePath() + this.defaultPath
					+ this.packageOutPath.replace(".", "/")+"entity" + "/" + initcap(entityName) + ".java";
			System.out.println("执行完毕，生成路径为："+outputPath);
			FileWriter fw = new FileWriter(outputPath);
			PrintWriter pw = new PrintWriter(fw);
			pw.println(content);
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @mapper TODO
	 */
	private void createMapper(){
		try{
			StringBuffer sb = new StringBuffer();
			sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n");
			sb.append("<!DOCTYPE mapper PUBLIC \"-//mybatis.org//DTD Mapper 3.0//EN\" \"http://mybatis.org/dtd/mybatis-3-mapper.dtd\">\r\n");
			sb.append("<mapper namespace=\"" + this.packageOutPath + "dao." + initcap(entityName) + "DAO\">\r\n");
			sb.append("\t<resultMap id=\"BaseResultMap\" type=\"" + this.packageOutPath + "entity." + initcap(entityName) +"\">\r\n");
			for(int i=0 ; i<colnames.length ; i++){
				sb.append("\t\t<result column=\""+colnames[i]+"\" property=\""+propertyNames[i]
						+"\" jdbcType=\""+ (colTypes[i].equals("INT")?"INTEGER":colTypes[i]) +"\"/>\r\n");
			}
			sb.append("\t</resultMap>\r\n\r\n");
			
			sb.append("\t<select id=\"selectBy\" resultMap=\"BaseResultMap\" parameterType=\""+ this.packageOutPath + "entity." + initcap(entityName) +"\">\r\n");
			sb.append("\t\tSELECT * FROM ").append(tablename).append(" WHERE 1=1");
			for(int i=0 ; i<propertyNames.length ; i++){
				sb.append("\r\n\t\t<if test=\""+propertyNames[i]+" != null and "+propertyNames[i]+" != ''\">\r\n");
				sb.append("\t\t\t").append("AND ").append(colnames[i]).append(" = #{").append(propertyNames[i]).append("}\r\n");
				sb.append("\t\t</if>");
			}
			sb.append("\r\n\t</select>\r\n\r\n");
			
			sb.append("\t<insert id=\"insertBy\" parameterType=\""+ this.packageOutPath + "entity." + initcap(entityName) +"\">\r\n");
			sb.append("\t\tINSERT INTO ").append(tablename);
			sb.append("\r\n\t\t(");
			for(int i=0 ; i<colnames.length ; i++){
				if(i == colnames.length -1){
					sb.append(colnames[i]);
				}else{
					if(i != 0 && i%4 != 0){
						sb.append(colnames[i]).append(",");
					}else{
						sb.append("\r\n\t\t\t").append(colnames[i]).append(",");
					}
				}
			}
			sb.append("\r\n\t\t)");
			sb.append("\r\n\t\tVALUES");
			sb.append("\r\n\t\t(");
			for(int i=0 ; i<propertyNames.length ; i++){
				if(i == propertyNames.length -1){
					sb.append("#{").append(propertyNames[i]).append("}");
				}else{
					if(i != 0 && i%4 != 0){
						sb.append("#{").append(propertyNames[i]).append("},");
					}else{
						sb.append("\r\n\t\t\t#{").append(propertyNames[i]).append("},");
					}
				}
			}
			sb.append("\r\n\t\t)");
			sb.append("\r\n\t</insert>\r\n\r\n");
			
			sb.append("\t<update id=\"updateBy\" parameterType=\""+ this.packageOutPath + "entity." + initcap(entityName) +"\">\r\n");
			sb.append("\t\tUPDATE ").append(tablename);
			sb.append("\r\n\t\t<set>");
			for(int i=0 ; i<propertyNames.length ; i++){
				sb.append("\r\n\t\t\t<if test=\""+propertyNames[i]+" != null and "+propertyNames[i]+" != ''\">\r\n");
				sb.append("\t\t\t\t").append(colnames[i]).append(" = #{").append(propertyNames[i]).append("},\r\n");
				sb.append("\t\t\t</if>");
			}
			sb.append("\r\n\t\t</set>");
			sb.append("\r\n\t\tWHERE ").append(colnames[0]).append(" = ").append("#{").append(propertyNames[0]).append("}");
			sb.append("\r\n\t</update>\r\n\r\n");
			
			sb.append("\t<delete id=\"deleteBy\" parameterType=\""+ this.packageOutPath + "entity." + initcap(entityName) +"\">\r\n");
			sb.append("\t\tDELETE FROM ").append(tablename).append(" WHERE 1=1");
			for(int i=0 ; i<propertyNames.length ; i++){
				sb.append("\r\n\t\t<if test=\""+propertyNames[i]+" != null and "+propertyNames[i]+" != ''\">\r\n");
				sb.append("\t\t\t").append("AND ").append(colnames[i]).append(" = #{").append(propertyNames[i]).append("}\r\n");
				sb.append("\t\t</if>");
			}
			sb.append("\r\n\t</delete>\r\n\r\n");
			sb.append("</mapper>");
//			System.out.println(sb.toString());
			File directory = new File("");
			
			String path = this.getClass().getResource("").getPath();
	
			System.out.println(path);
			
			String outputPath = directory.getAbsolutePath() + this.defaultPath2
					+ "mapper/" + initcap(entityName) + "Mapper.xml";
			System.out.println("执行完毕，生成路径为："+outputPath);
			FileWriter fw = new FileWriter(outputPath);
			PrintWriter pw = new PrintWriter(fw);
			pw.println(sb.toString());
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @dao TODO
	 */
	private void createDao(){
		try {
			StringBuffer sb = new StringBuffer();
			// 生成package包路径
			sb.append("package " + this.packageOutPath+"dao" + ";\r\n");
			sb.append("import java.util.List;\r\n");
			sb.append("import " + this.packageOutPath + "entity." + initcap(entityName) + ";\r\n");
			if(f_springboot){
				sb.append("import org.apache.ibatis.annotations.Mapper;\r\n");
			}
			sb.append("import org.springframework.stereotype.Repository;\r\n");
			
			sb.append("\r\n");
			// 注释部分
			sb.append("   /**\r\n");
			sb.append("    * @文件名称：" + this.entityName + "DAO.java\r\n");
			sb.append("    * @创建时间：" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + "\r\n");
			sb.append("    * @创  建  人：" + this.authorName + " \r\n");
			sb.append("    * @文件描述：" + tablename + " DAO\r\n");
	//		sb.append("    * @文件版本：" + this.version + " \r\n");
			sb.append("    */ \r\n");
			// 实体部分
			if(f_springboot){
				sb.append("\r\n@Mapper\r\n");
			}
			sb.append("@Repository\r\n");
//			sb.append("\r\n\r\npublic interface " + initcap(entityName) + "DAO{\r\n");
			sb.append("public interface " + initcap(entityName) + "DAO{\r\n");
			sb.append("\r\n\tpublic List<"+initcap(entityName)+"> selectBy("+initcap(entityName)+ " "+entityName+");\r\n");
			sb.append("\r\n\tpublic int insertBy("+initcap(entityName)+ " "+entityName+");\r\n");
			sb.append("\r\n\tpublic int updateBy("+initcap(entityName)+ " "+entityName+");\r\n");
			sb.append("\r\n\tpublic int deleteBy("+initcap(entityName)+ " "+entityName+");\r\n");
			sb.append("}\r\n");
			
			File directory = new File("");
			
			String path = this.getClass().getResource("").getPath();

			System.out.println(path);
			
			String outputPath = directory.getAbsolutePath() + this.defaultPath
					+ this.packageOutPath.replace(".", "/")+"dao" + "/" + initcap(entityName) + "DAO.java";
			System.out.println("执行完毕，生成路径为："+outputPath);
			FileWriter fw = new FileWriter(outputPath);
			PrintWriter pw = new PrintWriter(fw);
			pw.println(sb.toString());
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @service接口 TODO
	 */
	private void createServiceInterface(){
		try {
			StringBuffer sb = new StringBuffer();
			// 生成package包路径
			sb.append("package " + this.packageOutPath+"service" + ";\r\n");
			sb.append("import java.util.List;\r\n");
			sb.append("import " + this.packageOutPath + "entity." + initcap(entityName) + ";\r\n");
			
			sb.append("\r\n");
			// 注释部分
			sb.append("   /**\r\n");
			sb.append("    * @文件名称：" + this.entityName + "Service.java\r\n");
			sb.append("    * @创建时间：" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + "\r\n");
			sb.append("    * @创  建  人：" + this.authorName + " \r\n");
			sb.append("    * @文件描述：" + tablename + " Service\r\n");
			sb.append("    */ \r\n");
			sb.append("public interface " + initcap(entityName) + "Service{\r\n");
			sb.append("\r\n\tpublic List<"+initcap(entityName)+"> selectBy("+initcap(entityName)+ " "+entityName+");\r\n");
			sb.append("\r\n\tpublic int insertBy("+initcap(entityName)+ " "+entityName+");\r\n");
			sb.append("\r\n\tpublic int updateBy("+initcap(entityName)+ " "+entityName+");\r\n");
			sb.append("\r\n\tpublic int deleteBy("+initcap(entityName)+ " "+entityName+");\r\n");
			sb.append("}\r\n");
			
			File directory = new File("");
			
			String path = this.getClass().getResource("").getPath();

			System.out.println(path);
			
			String outputPath = directory.getAbsolutePath() + this.defaultPath
					+ this.packageOutPath.replace(".", "/")+"service" + "/" + initcap(entityName) + "Service.java";
			System.out.println("执行完毕，生成路径为："+outputPath);
			FileWriter fw = new FileWriter(outputPath);
			PrintWriter pw = new PrintWriter(fw);
			pw.println(sb.toString());
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @service实现类 TODO
	 */
	private void createServiceimpl(){
		try {
			StringBuffer sb = new StringBuffer();
			// 生成package包路径
			sb.append("package " + this.packageOutPath+"service.impl" + ";\r\n");
			sb.append("import java.util.List;\r\n");
			sb.append("import " + this.packageOutPath + "entity." + initcap(entityName) + ";\r\n");
			sb.append("import org.springframework.beans.factory.annotation.Autowired;\r\n");
			sb.append("import org.springframework.stereotype.Service;\r\n");
			sb.append("import " + this.packageOutPath + "service." + initcap(entityName) + "Service;\r\n");
			sb.append("import " + this.packageOutPath + "dao." + initcap(entityName) + "DAO;\r\n");
			
			sb.append("\r\n");
			// 注释部分
			sb.append("   /**\r\n");
			sb.append("    * @文件名称：" + this.entityName + "ServiceImpl.java\r\n");
			sb.append("    * @创建时间：" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + "\r\n");
			sb.append("    * @创  建  人：" + this.authorName + " \r\n");
			sb.append("    * @文件描述：" + tablename + " ServiceImpl\r\n");
			sb.append("    */ \r\n");
			// 实体部分
			sb.append("@Service\r\n");
			sb.append("public class " + initcap(entityName) + "ServiceImpl implements "+ initcap(entityName) + "Service{\r\n");
			sb.append("\r\n\t@Autowired");
			sb.append("\r\n\tprivate " + initcap(entityName) + "DAO dao;\r\n");
			
			sb.append("\r\n\t@Override");
			sb.append("\r\n\tpublic List<"+initcap(entityName)+"> selectBy("+initcap(entityName)+ " "+entityName+"){\r\n");
			sb.append("\t\treturn dao.selectBy("+entityName+");\r\n");
			sb.append("\t}\r\n");
			sb.append("\r\n\t@Override");
			sb.append("\r\n\tpublic int insertBy("+initcap(entityName)+ " "+entityName+"){\r\n");
			sb.append("\t\treturn dao.insertBy("+entityName+");\r\n");
			sb.append("\t}\r\n");
			sb.append("\r\n\t@Override");
			sb.append("\r\n\tpublic int updateBy("+initcap(entityName)+ " "+entityName+"){\r\n");
			sb.append("\t\treturn dao.updateBy("+entityName+");\r\n");
			sb.append("\t}\r\n");
			sb.append("\r\n\t@Override");
			sb.append("\r\n\tpublic int deleteBy("+initcap(entityName)+ " "+entityName+"){\r\n");
			sb.append("\t\treturn dao.deleteBy("+entityName+");\r\n");
			sb.append("\t}\r\n");
			sb.append("}\r\n");
			
			File directory = new File("");
			
			String path = this.getClass().getResource("").getPath();

			System.out.println(path);
			
			String outputPath = directory.getAbsolutePath() + this.defaultPath
					+ this.packageOutPath.replace(".", "/")+"service/impl" + "/" + initcap(entityName) + "ServiceImpl.java";
			System.out.println("执行完毕，生成路径为："+outputPath);
			FileWriter fw = new FileWriter(outputPath);
			PrintWriter pw = new PrintWriter(fw);
			pw.println(sb.toString());
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @controller TODO
	 */
	private void createController(){
		try {
			StringBuffer sb = new StringBuffer();
			// 生成package包路径
			sb.append("package " + this.packageOutPath+"controller" + ";\r\n");
			sb.append("import java.util.List;\r\n");
			sb.append("import " + this.packageOutPath + "entity." + initcap(entityName) + ";\r\n");
			sb.append("import org.springframework.beans.factory.annotation.Autowired;\r\n");
			sb.append("import org.springframework.web.bind.annotation.RequestMapping;");
			if(f_springboot){
				sb.append("import org.springframework.web.bind.annotation.PostMapping;");
				sb.append("import org.springframework.web.bind.annotation.RequestBody;");
				sb.append("import org.springframework.web.bind.annotation.RestController;\r\n");
			}else{
				sb.append("import org.springframework.stereotype.Controller;");
				sb.append("import org.springframework.web.bind.annotation.ResponseBody;");
			}
			sb.append("import " + this.packageOutPath + "service." + initcap(entityName) + "Service;\r\n");
			sb.append("\r\n");
			// 注释部分
			sb.append("   /**\r\n");
			sb.append("    * @文件名称：" + this.entityName + "Controller.java\r\n");
			sb.append("    * @创建时间：" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()) + "\r\n");
			sb.append("    * @创  建  人：" + this.authorName + " \r\n");
			sb.append("    * @文件描述：" + tablename + " Controller\r\n");
			sb.append("    */ \r\n");
			// 实体部分
			sb.append("@RequestMapping(\"/"+entityName+"\")\r\n");
			if(f_springboot){
				sb.append("@RestController\r\n");
			}else{
				sb.append("@Controller\r\n");
			}
			sb.append("public class " + initcap(entityName) + "Controller {\r\n");
			sb.append("\r\n\t@Autowired");
			sb.append("\r\n\tprivate " + initcap(entityName) + "Service service;\r\n");
			
			if(f_springboot){
				sb.append("\r\n\t@PostMapping(\"/selectBy\")");
				sb.append("\r\n\tpublic List<"+initcap(entityName)+"> selectBy(@RequestBody "+initcap(entityName)+ " "+entityName+"){\r\n");
			}else{
				sb.append("\r\n\t@RequestMapping(value = \"/selectBy\",method=RequestMethod.POST)");
				sb.append("\r\n\t@ResponseBody");
				sb.append("\r\n\tpublic List<"+initcap(entityName)+"> selectBy(HttpServletRequest request, HttpServletResponse response, "+initcap(entityName)+ " "+entityName+"){\r\n");
			}
			sb.append("\t\treturn service.selectBy("+entityName+");\r\n");
			sb.append("\t}\r\n");
			if(f_springboot){
				sb.append("\r\n\t@PostMapping(\"/insertBy\")");
				sb.append("\r\n\tpublic int insertBy(@RequestBody "+initcap(entityName)+ " "+entityName+"){\r\n");
			}else{
				sb.append("\r\n\t@RequestMapping(value = \"/insertBy\",method=RequestMethod.POST)");
				sb.append("\r\n\t@ResponseBody");
				sb.append("\r\n\tpublic int insertBy(HttpServletRequest request, HttpServletResponse response, "+initcap(entityName)+ " "+entityName+"){\r\n");
			}
			sb.append("\t\treturn service.insertBy("+entityName+");\r\n");
			sb.append("\t}\r\n");
			if(f_springboot){
				sb.append("\r\n\t@PostMapping(\"/updateBy\")");
				sb.append("\r\n\tpublic int updateBy(@RequestBody "+initcap(entityName)+ " "+entityName+"){\r\n");
			}else{
				sb.append("\r\n\t@RequestMapping(value = \"/updateBy\",method=RequestMethod.POST)");
				sb.append("\r\n\t@ResponseBody");
				sb.append("\r\n\tpublic int updateBy(HttpServletRequest request, HttpServletResponse response, "+initcap(entityName)+ " "+entityName+"){\r\n");
			}
			sb.append("\t\treturn service.updateBy("+entityName+");\r\n");
			sb.append("\t}\r\n");
			if(f_springboot){
				sb.append("\r\n\t@PostMapping(\"/deleteBy\")");
				sb.append("\r\n\tpublic int deleteBy(@RequestBody "+initcap(entityName)+ " "+entityName+"){\r\n");
			}else{
				sb.append("\r\n\t@RequestMapping(value = \"/deleteBy\",method=RequestMethod.POST)");
				sb.append("\r\n\t@ResponseBody");
				sb.append("\r\n\tpublic int deleteBy(HttpServletRequest request, HttpServletResponse response, "+initcap(entityName)+ " "+entityName+"){\r\n");
			}
			sb.append("\t\treturn service.deleteBy("+entityName+");\r\n");
			sb.append("\t}\r\n");
			sb.append("}\r\n");
			
			File directory = new File("");
			
			String path = this.getClass().getResource("").getPath();

			System.out.println(path);
			
			String outputPath = directory.getAbsolutePath() + this.defaultPath
					+ this.packageOutPath.replace(".", "/")+"controller/" + initcap(entityName) + "Controller.java";
			System.out.println("执行完毕，生成路径为："+outputPath);
			FileWriter fw = new FileWriter(outputPath);
			PrintWriter pw = new PrintWriter(fw);
			pw.println(sb.toString());
			pw.flush();
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 出口 TODO
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
 
		new SqlHelper();
 
	}
}