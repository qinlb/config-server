package com.boot.app.user.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.app.user.dao.SysUserMapper;
import com.boot.app.user.entity.SysUserInfo;
import com.boot.app.user.service.SysUserService;

@Service
public class SysUserServiceImpl implements SysUserService{

	@Autowired
	private SysUserMapper dao;
	
	@Override
	public SysUserInfo getUser(String itCode) {
		return dao.getUserInfo(itCode);
	}

}
