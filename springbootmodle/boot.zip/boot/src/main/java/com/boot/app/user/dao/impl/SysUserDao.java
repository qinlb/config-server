package com.boot.app.user.dao.impl;

public class SysUserDao{}
//@Repository
//public class SysUserDao implements SysUserMapper{
//
//	@Autowired
//    private JdbcTemplate jdbcTemplate;
//	
//	@SuppressWarnings({ "unchecked", "rawtypes" })
//	@Override
//	public SysUserInfo getUserInfo(String itCode) {
//		List<SysUserInfo> userList = jdbcTemplate.query("select * FROM sys_user WHERE ITcode = ?",new Object[]{itCode},new BeanPropertyRowMapper(SysUserInfo.class));
//        if(userList != null && userList.size() > 0){
//        	SysUserInfo user = userList.get(0);
//            return user;
//        }else {
//            return null;
//        }
//	}
//
//}
