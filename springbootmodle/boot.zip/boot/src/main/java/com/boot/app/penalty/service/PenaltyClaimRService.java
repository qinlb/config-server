package com.boot.app.penalty.service;
import java.util.List;
import com.boot.app.penalty.entity.PenaltyClaimR;

   /**
    * @文件名称：penaltyClaimRService.java
    * @创建时间：2019-05-06 18:18:35
    * @创  建  人：qinlb 
    * @文件描述：upload_penalty_claim_r Service
    */ 
public interface PenaltyClaimRService{

	public List<PenaltyClaimR> selectBy(PenaltyClaimR penaltyClaimR);

	public int insertBy(PenaltyClaimR penaltyClaimR);

	public int updateBy(PenaltyClaimR penaltyClaimR);

	public int deleteBy(PenaltyClaimR penaltyClaimR);
}

