package com.boot.app.penalty.service.impl;
import java.util.List;
import com.boot.app.penalty.entity.PenaltyClaimR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.boot.app.penalty.service.PenaltyClaimRService;
import com.boot.app.penalty.dao.PenaltyClaimRDAO;

   /**
    * @文件名称：penaltyClaimRServiceImpl.java
    * @创建时间：2019-05-06 18:18:35
    * @创  建  人：qinlb 
    * @文件描述：upload_penalty_claim_r ServiceImpl
    */ 
@Service
public class PenaltyClaimRServiceImpl implements PenaltyClaimRService{

	@Autowired
	private PenaltyClaimRDAO dao;

	@Override
	public List<PenaltyClaimR> selectBy(PenaltyClaimR penaltyClaimR){
		return dao.selectBy(penaltyClaimR);
	}

	@Override
	public int insertBy(PenaltyClaimR penaltyClaimR){
		return dao.insertBy(penaltyClaimR);
	}

	@Override
	public int updateBy(PenaltyClaimR penaltyClaimR){
		return dao.updateBy(penaltyClaimR);
	}

	@Override
	public int deleteBy(PenaltyClaimR penaltyClaimR){
		return dao.deleteBy(penaltyClaimR);
	}
}

