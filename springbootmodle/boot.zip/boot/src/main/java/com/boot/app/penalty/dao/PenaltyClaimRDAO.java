package com.boot.app.penalty.dao;
import java.util.List;
import com.boot.app.penalty.entity.PenaltyClaimR;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

   /**
    * @文件名称：penaltyClaimRDAO.java
    * @创建时间：2019-05-06 18:18:35
    * @创  建  人：qinlb 
    * @文件描述：upload_penalty_claim_r DAO
    */ 

@Mapper
@Repository
public interface PenaltyClaimRDAO{

	public List<PenaltyClaimR> selectBy(PenaltyClaimR penaltyClaimR);

	public int insertBy(PenaltyClaimR penaltyClaimR);

	public int updateBy(PenaltyClaimR penaltyClaimR);

	public int deleteBy(PenaltyClaimR penaltyClaimR);
}

