package com.boot.app.user.dao;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.boot.app.user.entity.SysUserInfo;

@Mapper
@Repository
public interface SysUserMapper{
	
	public SysUserInfo getUserInfo(String itCode);
}
