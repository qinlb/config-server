package com.boot.app.user.service;

import com.boot.app.user.entity.SysUserInfo;

public interface SysUserService {

	public SysUserInfo getUser(String itCode);
}
