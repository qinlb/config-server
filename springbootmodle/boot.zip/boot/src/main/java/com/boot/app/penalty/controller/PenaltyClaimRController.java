package com.boot.app.penalty.controller;
import java.util.List;
import com.boot.app.penalty.entity.PenaltyClaimR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;import org.springframework.web.bind.annotation.PostMapping;import org.springframework.web.bind.annotation.RequestBody;import org.springframework.web.bind.annotation.RestController;
import com.boot.app.penalty.service.PenaltyClaimRService;

   /**
    * @文件名称：penaltyClaimRController.java
    * @创建时间：2019-05-06 18:18:35
    * @创  建  人：qinlb 
    * @文件描述：upload_penalty_claim_r Controller
    */ 
@RequestMapping("/penaltyClaimR")
@RestController
public class PenaltyClaimRController {

	@Autowired
	private PenaltyClaimRService service;

	@PostMapping("/selectBy")
	public List<PenaltyClaimR> selectBy(@RequestBody PenaltyClaimR penaltyClaimR){
		return service.selectBy(penaltyClaimR);
	}

	@PostMapping("/insertBy")
	public int insertBy(@RequestBody PenaltyClaimR penaltyClaimR){
		return service.insertBy(penaltyClaimR);
	}

	@PostMapping("/updateBy")
	public int updateBy(@RequestBody PenaltyClaimR penaltyClaimR){
		return service.updateBy(penaltyClaimR);
	}

	@PostMapping("/deleteBy")
	public int deleteBy(@RequestBody PenaltyClaimR penaltyClaimR){
		return service.deleteBy(penaltyClaimR);
	}
}

