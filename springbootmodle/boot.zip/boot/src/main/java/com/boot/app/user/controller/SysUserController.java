package com.boot.app.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.app.common.aop.ExceptionHandle;
import com.boot.app.common.aop.entity.ExceptionEnum;
import com.boot.app.common.aop.entity.Result;
import com.boot.app.common.aop.util.ResultUtil;
import com.boot.app.user.entity.SysUserInfo;
import com.boot.app.user.service.SysUserService;

@RequestMapping("/user")
@RestController
public class SysUserController {
	@Autowired
    private ExceptionHandle exceptionHandle;
	
	@Autowired
	private SysUserService service;
	
	@SuppressWarnings("rawtypes")
	@PostMapping("/getUser/{itCode}")
	public Result getUserInfo(@PathVariable("itCode")String itCode ){
		Result result = ResultUtil.success();
		try {
        	SysUserInfo info = service.getUser(itCode);
            if (info != null){
                result =  ResultUtil.success(info);
            }else{
                result =  ResultUtil.error(ExceptionEnum.USER_NOT_FIND);
            }
        }catch (Exception e){
            result =  exceptionHandle.exceptionGet(e);
        }
        return result;
	}

}
