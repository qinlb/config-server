package com.config.client.app;

public class SysUserInfo {

	private int id; 
	private String ITcode; 
	private String display_name; 
	private String mail; 
	private String login_type; 
	private String PASSWORD; 
	private short is_delete;
	private String rule;
	private int user_log_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getITcode() {
		return ITcode;
	}
	public void setITcode(String iTcode) {
		ITcode = iTcode;
	}
	public String getDisplay_name() {
		return display_name;
	}
	public void setDisplay_name(String display_name) {
		this.display_name = display_name;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getLogin_type() {
		return login_type;
	}
	public void setLogin_type(String login_type) {
		this.login_type = login_type;
	}
	public String getPASSWORD() {
		return PASSWORD;
	}
	public void setPASSWORD(String pASSWORD) {
		PASSWORD = pASSWORD;
	}
	public short getIs_delete() {
		return is_delete;
	}
	public void setIs_delete(short is_delete) {
		this.is_delete = is_delete;
	}
	public String getRule() {
		return rule;
	}
	public void setRule(String rule) {
		this.rule = rule;
	}
	public int getUser_log_id() {
		return user_log_id;
	}
	public void setUser_log_id(int user_log_id) {
		this.user_log_id = user_log_id;
	}
	
}
