package com.config.client;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.config.client.app.SysUserInfo;

/**
 * Hello world!
 *
 */
@RestController
@SpringBootApplication
public class App 
{
	@Autowired
	private JdbcTemplate jdbct;
	
    public static void main( String[] args )
    {
       SpringApplication.run(App.class, args);
    }
    @Value("${hello}")
    String hello;
    @RequestMapping(value = "/hello")
    public String hello(){
        return hello;
    }
    
    @RequestMapping(value = "/hello2")
    public SysUserInfo hello2(){
    	List<SysUserInfo> userList = jdbct.query("select * FROM sys_user WHERE ITcode = ?",new Object[]{"wanglw8"},new BeanPropertyRowMapper(SysUserInfo.class));
	      if(userList != null && userList.size() > 0){
	      	return userList.get(0);
	      }else {
	          return null;
	      }
    }
}
